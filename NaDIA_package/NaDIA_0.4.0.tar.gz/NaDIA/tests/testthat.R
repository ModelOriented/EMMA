library(testthat)
library(NaDIA)

test_check("NaDIA")
