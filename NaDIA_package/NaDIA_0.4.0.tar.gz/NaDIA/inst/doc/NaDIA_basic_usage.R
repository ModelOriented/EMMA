## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup,include=FALSE------------------------------------------------------
knitr::opts_chunk$set(
	message = FALSE,
	warning = FALSE,
	include = FALSE
)
library(NaDIA)

## ----echo=FALSE, out.width='100%', include=TRUE, fig.align='center'-----------
knitr::include_graphics('diagram.png')

## ----chunk1, echo=TRUE, include=TRUE , cache=TRUE, class.source="code"--------
# Task with missing data from mlr3
task_with_missing <- tsk('pima')

task_with_missing$missings()

# Creating an operator implementing the imputation method
imputation_methods <- PipeOpMice$new()

# Imputation
task_with_no_missing <- imputation_methods$train(list(task_with_missing))[[1]]

task_with_no_missing$missings()


## ----chunk2, include=TRUE,cache=TRUE , class.source="code"--------------------
library(mlr3learners)

# Creating graph learner

# imputation method 
imp <- PipeOpmissRanger$new()

# encoder 
encoder <- PipeOpEncodeImpact$new()

# learner 
learner <- lrn('classif.glmnet')

graph <- imp %>>% encoder %>>% learner

graph_lerner <- GraphLearner$new(graph, id = 'missRanger.learner')

# resampling 
set.seed(1)
resample(tsk('pima'),graph_lerner,rsmp('cv',folds=5))

## ----chunk3,include=TRUE, dependson= -1 ,cache=TRUE, class.source="code"------
# Error handling 
graph_lerner$encapsulate <- c(train='evaluate',predict='evaluate')

# Creating a problematic task
data <- iris

data[,1] <- NA

task_problematic <- TaskClassif$new('task',data,'Species')


# Resampling 

# All folds will be tested and the script run forward 

set.seed(1)
resample(task_problematic,graph_lerner,rsmp('cv',folds=5))




## ----chunk4, include=TRUE,dependson=-2 ,cache=TRUE, class.source="code"-------

# Turning off encapsulation 
graph_lerner$encapsulate <- c(train='none',predict='none')

# Turning on optimalization 
graph_lerner$param_set$values$impute_missRanger_B.optimize <- TRUE


# Resampling 
set.seed(1)
resample(tsk('pima'),graph_lerner,rsmp('cv',folds=5))


## ----include=TRUE ,cache=TRUE, class.source="code"----------------------------

# Creating graph learner

# imputation method 
imp <- PipeOpMean_B$new()

# encoder 
encoder <- PipeOpEncodeImpact$new()

# learner 
learner <- lrn('classif.glmnet')

graph <- imp %>>% encoder %>>% learner

graph_lerner <- GraphLearner$new(graph)

# resampling 
set.seed(1)
resample(tsk('pima'),graph_lerner,rsmp('cv',folds=5))


