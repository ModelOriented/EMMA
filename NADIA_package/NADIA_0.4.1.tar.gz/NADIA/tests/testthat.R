library(testthat)
library(NADIA)

test_check("NADIA")
