
Pipeline <- function(df,col_type,percent_of_missing){
  col_miss <- colnames(df)[percent_of_missing>0]
  col_no_miss <- colnames(df)[percent_of_missing==0]

  mice_result <- autotune_mice(df,col_miss=col_miss,col_no_miss=col_no_miss,percent_of_missing=percent_of_missing,col_type = col_type,iter = 5)
  missMDA_result_1 <- missMDA_FMAD_MCA_PCA(df,col_type,percent_of_missing)
  missMDA_result_2 <- missMDA_MFA(df,col_type,percent_of_missing)
  missForest_result <- autotune_missForest(df,percent_of_missing)
  return(list(mice_result,missMDA_result_1,missMDA_result_2,missForest_result))

}



#### TESTING ####
df <- df
id <- id
df_info<- read_json(paste("./datasets_store/information_base/dataset_", id, ".json", sep = "")) # not realy usfull

col_type <- 1:ncol(df)
for ( i in col_type){
 col_type[i] <- class(df[,i])
}

percent_of_missing  <- 1:ncol(df)
for ( i in percent_of_missing){
  percent_of_missing[i] <- (sum(is.na(df[,i]))/length(df[,1]))*100
}

col_miss <- colnames(df)[percent_of_missing>0]
col_no_miss <- colnames(df)[percent_of_missing==0]


test <- Pipeline(df,col_type,percent_of_missing)
