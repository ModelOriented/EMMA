library(testthat)
library(EMMA)

test_check("EMMA")
